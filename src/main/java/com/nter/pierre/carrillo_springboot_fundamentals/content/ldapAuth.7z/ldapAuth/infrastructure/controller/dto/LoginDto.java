package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.controller.dto;

import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security.UserDetailsImpl;
import lombok.Builder;
import lombok.Getter;
import java.util.List;
@Getter
@Builder
public class LoginDto {
    private String type; private String token; private String refreshToken;
    private List<String> authorities; private String username;
    private UserDetailsImpl.UserType userType;
}