package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.application.service;


import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security.JwtUtils;
import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security.UserDetailsImpl;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class LoginUseCase {

    private final AuthenticationManager authenticationManager; // el wrapper
    private final JwtUtils jwtUtils;

    public LoginUseCase(@Qualifier("ldapAuthenticationManager")
                        AuthenticationManager authenticationManager,
                        JwtUtils jwtUtils) {
        this.authenticationManager = authenticationManager;
        this.jwtUtils = jwtUtils;
    }

    public Output execute(Input input) {
        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(input.username(), input.password()));

        UserDetailsImpl principal = (UserDetailsImpl) auth.getPrincipal();

        String accessToken  = jwtUtils.generateJwtToken(auth, false);
        String refreshToken = jwtUtils.generateJwtToken(auth, true);

        List<String> authorities = auth.getAuthorities()
                .stream().map(GrantedAuthority::getAuthority).toList();

        return new Output(
                "Bearer",
                accessToken,
                refreshToken,
                principal.getUsername(),
                principal.getUserType().name(),
                authorities
        );
    }

    public record Input(String username, String password) {}

    public record Output(
            String type,
            String token,
            String refreshToken,
            String username,
            String userType,
            List<String> authorities
    ) {}
}