package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security;

import lombok.Builder;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@Getter
@Builder
public class UserDetailsImpl implements UserDetails {
    public enum UserType { DATABASE, LDAP }
    private String username;
    private UserType userType;
    @Builder.Default private Collection<? extends GrantedAuthority> authorities = List.of();
    @Override public String getPassword() { return null; }
    @Override public boolean isAccountNonExpired() { return true; }
    @Override public boolean isAccountNonLocked() { return true; }
    @Override public boolean isCredentialsNonExpired() { return true; }
    @Override public boolean isEnabled() { return true; }
}
