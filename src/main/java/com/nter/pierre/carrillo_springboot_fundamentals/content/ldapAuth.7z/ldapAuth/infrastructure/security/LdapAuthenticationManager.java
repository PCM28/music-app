package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security;

import org.springframework.beans.factory.annotation.Qualifier;   // <-- este
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.ldap.userdetails.LdapUserDetailsImpl;
import org.springframework.stereotype.Component;

@Component
@Primary
@Profile("LDAPAuth")
public class LdapAuthenticationManager implements AuthenticationManager {

    private final AuthenticationManager baseAuthManager;

    public LdapAuthenticationManager(@Qualifier("baseLdapAuthManager")
                                     AuthenticationManager baseAuthManager) {
        this.baseAuthManager = baseAuthManager;
    }

    @Override
    public Authentication authenticate(Authentication authentication) {
        Authentication baseAuth = baseAuthManager.authenticate(authentication);
        LdapUserDetailsImpl ldapUser = (LdapUserDetailsImpl) baseAuth.getPrincipal();
        var authorities = baseAuth.getAuthorities().stream()
                .map(a -> new SimpleGrantedAuthority(a.getAuthority()))
                .toList();

        var principal = UserDetailsImpl.builder()
                .username(ldapUser.getUsername())
                .userType(UserDetailsImpl.UserType.LDAP)
                .authorities(authorities)
                .build();

        return new UsernamePasswordAuthenticationToken(principal, null, authorities);
    }
}
