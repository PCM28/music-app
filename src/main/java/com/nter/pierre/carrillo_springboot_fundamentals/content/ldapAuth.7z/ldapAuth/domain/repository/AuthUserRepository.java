package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.domain.repository;

import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.domain.entity.AuthUser;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.JpaRepository;

@Profile("!LDAPAuth")
public interface AuthUserRepository extends JpaRepository<AuthUser, Long> {}
