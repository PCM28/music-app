package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.application.mapper;

import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.domain.entity.AuthUser;
import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security.UserDetailsImpl;
import org.springframework.security.core.GrantedAuthority;

import java.util.Set;
import java.util.stream.Collectors;

public final class UserDetailsMapper {

    private UserDetailsMapper() {}

    public static AuthUser toDomain(UserDetailsImpl ud) {
        Set<String> roles = ud.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority).collect(Collectors.toSet());
        // Si no tienes DN/displayName/email, pasa null o vacíos
        return AuthUser.ldap(ud.getUsername(), roles, null, null, null);
    }


}
