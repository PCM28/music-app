package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.ldap.LdapBindAuthenticationManagerFactory;
import org.springframework.security.ldap.userdetails.DefaultLdapAuthoritiesPopulator;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

@Configuration
@Profile("LDAPAuth")
@EnableMethodSecurity
public class WebSecurityConfigLDAP extends WebSecurityConfigAbstract {

    public WebSecurityConfigLDAP(JwtFilter jwtFilter,
                                 AuthenticationEntryPoint authenticationEntryPoint) {
        super(jwtFilter, authenticationEntryPoint);
    }

    @Bean
    public SecurityFilterChain securityFilterChainLDAP(HttpSecurity http) throws Exception {
        super.securityFilterChainPrivate(http); // no seteamos authenticationManager aquí
        return http.build();
    }

    // OJO: dale un nombre explícito al bean base
    @Bean("baseLdapAuthManager")
    public AuthenticationManager authenticationManager(BaseLdapPathContextSource ctx,
                                                       LdapAuthoritiesPopulator populator) {
        var factory = new LdapBindAuthenticationManagerFactory(ctx);
        factory.setUserDnPatterns("uid={0},ou=people");
        factory.setLdapAuthoritiesPopulator(populator);
        return factory.createAuthenticationManager(); // <-- manager BASE de LDAP
    }

    @Bean
    public LdapAuthoritiesPopulator ldapAuthoritiesPopulator(BaseLdapPathContextSource ctx) {
        var pop = new DefaultLdapAuthoritiesPopulator(ctx, "ou=groups");
        pop.setGroupSearchFilter("uniqueMember={0}");
        pop.setGroupRoleAttribute("cn");
        pop.setRolePrefix("ROLE_");
        pop.setSearchSubtree(true);
        pop.setIgnorePartialResultException(true);
        return pop;
    }
}
