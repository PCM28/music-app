package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;

import java.util.List;

@Configuration
@Profile("LDAPAuth")
public class SecurityLDAPConfig {
    @Value("${spring.ldap.urls}")     private String url;
    @Value("${spring.ldap.base}")     private String base;
    @Value("${spring.ldap.username}") private String userDn;
    @Value("${spring.ldap.password}") private String pass;

    @Bean
    public DefaultSpringSecurityContextSource contextSource() {
        var cs = new DefaultSpringSecurityContextSource(List.of(url), base);
        cs.setUserDn(userDn);
        cs.setPassword(pass);
        return cs;
    }
}