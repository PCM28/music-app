package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;
import java.util.Set;

@Getter @Setter @Builder
@AllArgsConstructor @NoArgsConstructor
@Entity @Table(name = "users",
        indexes = @Index(name = "uk_users_username", columnList = "username", unique = true))
public class AuthUser {

    public enum Provider { LDAP, DATABASE }

    @Id
    @UuidGenerator
    @GeneratedValue
    private java.util.UUID id;

    @Column(nullable = false, unique = true, length = 190)
    private String username;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    private Provider provider;        // para LDAP ponlo a LDAP si algún día guardas

    @Column(name = "ldap_dn", length = 512)
    private String dn;                // opcional

    private String displayName;       // opcional

    @Column(length = 254)
    private String email;             // opcional

    @Transient
    private Set<String> roles;        // vienen de LDAP → NO persistir


    public static AuthUser ldap(String username,
                                Set<String> roles,
                                String dn,
                                String displayName,
                                String email) {
        return AuthUser.builder()
                .username(username)
                .provider(Provider.LDAP)
                .dn(dn)
                .displayName(displayName)
                .email(email)
                .roles(roles)     // si NO quieres persistir roles, marca el campo como @Transient
                .build();
    }

}
