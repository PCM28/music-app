package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

@Component
public class JwtUtils {

    @Value("${jwt.secret}") private String jwtSecret;
    @Value("${jwt.issuer:example}") private String issuer;
    @Value("${jwt.expirationMs:3600000}") private long expMs;

    private static final String CLAIM_USER_TYPE = "userType";
    private static final String CLAIM_ROLES = "roles";

    public String generateJwtToken(Authentication auth, boolean refresh) {
        var ud = (UserDetailsImpl) auth.getPrincipal();
        long extra = refresh ? 600000L : 0L; // +10 min en refresh
        SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64URL.decode(jwtSecret));
        return Jwts.builder()
                .claims()
                .issuer(issuer)
                .subject(ud.getUsername())
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expMs + extra))
                .add(CLAIM_USER_TYPE, ud.getUserType().name())
                .add(CLAIM_ROLES, auth.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList())
                .and()
                .signWith(key)
                .compact();
    }

    public Optional<UserDetailsImpl> validateJwtToken(String token) {
        try {
            SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64URL.decode(jwtSecret));
            Claims c = Jwts.parser().verifyWith(key).build()
                    .parseSignedClaims(token).getPayload();

            @SuppressWarnings("unchecked")
            List<String> roles = (List<String>) c.get(CLAIM_ROLES, List.class);

            var ud = UserDetailsImpl.builder()
                    .username(c.getSubject())
                    .userType(UserDetailsImpl.UserType.valueOf((String) c.get(CLAIM_USER_TYPE)))
                    .authorities(roles.stream().map(SimpleGrantedAuthority::new).toList())
                    .build();

            return Optional.of(ud);
        } catch (JwtException | IllegalArgumentException e) {
            return Optional.empty();
        }
    }
}
