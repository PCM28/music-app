package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.controller;

import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security.JwtUtils;
import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.controller.dto.InputLoginDto;
import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.controller.dto.LoginDto;
import com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.security.UserDetailsImpl;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;

    public AuthController(
            @Qualifier("ldapAuthenticationManager") AuthenticationManager authenticationManager, // <-- AQUÍ
            JwtUtils jwtUtils
    ) {
        this.authenticationManager = authenticationManager;
        this.jwtUtils = jwtUtils;
    }

    @PostMapping("/login")
    public LoginDto login(@RequestBody InputLoginDto in) {
        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(in.getUsername(), in.getPassword()));

        UserDetailsImpl ud = (UserDetailsImpl) auth.getPrincipal();

        return LoginDto.builder()
                .type("Bearer")
                .token(jwtUtils.generateJwtToken(auth, false))
                .refreshToken(jwtUtils.generateJwtToken(auth, true))
                .authorities(auth.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList())
                .username(ud.getUsername())
                .userType(ud.getUserType())
                .build();
    }
}

