package com.nter.pierre.carrillo_springboot_fundamentals.content.ldapAuth.infrastructure.controller.dto;

import lombok.Data;
@Data
public class InputLoginDto {
    private String username;
    private String password;
}